Armadillo No Hurt Sound - Minecraft Java 26.3

Mutes:
- minecraft:entity.armadillo.hurt
- minecraft:entity.armadillo.hurt_reduced

Install the ZIP into .minecraft/resourcepacks and enable it.
